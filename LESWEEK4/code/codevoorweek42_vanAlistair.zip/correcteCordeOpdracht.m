% Deze file hoort bij de opdracht van week 4 deel 2.
% 
% Hieronder vind je een stuk code. Het is de bedoeling om van een aantal 
% krachtmetingen het bijbehorende MVC te bepalen.
%
% Uiteindelijk moet er bij het runnen van deze file een figuur gemaakt
% worden waar de krachtsignalen in een subplot komen en de percentages MVC
% als een bar plot. Ook wordt de meest krachtige meting met rood gekleurd.
%
% Echter, we hebben een hoop fouten gemaakt. Het is aan jullie om de fouten
% te verbeteren aan de hand van de foutmeldingen die Matlab geeft.Daarnaast
% zijn er ook andere fouten waardoor het programma wel werkt, maar niet het
% gewenste resultaat geeft. In de reader staan de correct resultaten.
%
% 
%
%% Inladen van de data
%
%  Er zijn twee files, een met de MVC meting en een met een aantal
%  krachtmetingen. De samplefrequenty is 120 Hz
MVCData     = load('MVC.txt');
Kracht  = load('Krachtmetingen.txt');


%% Een eerste plot
%
% We maken een tijdsas
fs          = 1024;
tijdMVC     = (0:size(MVCData,2)-1)/fs;
tijdKracht  = (0:size(Kracht,1)-1)/fs;

% Een eerste plot van de data
figure
subplot(2,1,1)
plot(tijdMVC,MVCData);
xlabel('Tijd [s]');
ylabel('Kracht [N]');
title('MVC meting');

subplot(2,1,2)
plot(tijdKracht,Kracht);
xlabel('Tijd [s]');
ylabel('Kracht [N]');
legend({'Meting 1','Meting 2','Meting 3','Meting 4','Meting 5'});
title('Krachtmetingen');

%% Het bepalen van de MVC waarde
%
% De MVC waarde vinden we door het maximum te nemen van de MVC meting. We
% willen ook weten op welk tijdstip dit maximum plaatsvond
[MVCWaarde, MVCIndex] = max(MVCData);
maxTijdstip = tijdMVC(MVCIndex);
disp(['De maximale waarde is ', num2str(MVCWaarde) ' N, op ' num2str(maxTijdstip) ' seconden']);

%% Het bepalen van het percentage MVC voor elke krachtmeting
%
% We bepalen het percentage voor elke meting voor elke tijdstip
aantalMetingen = 5;
krachtInMVC = zeros(size(Kracht));

for meting = 1:aantalMetingen
    krachtInMVC(:,meting) = 100*Kracht(:,meting)/MVCWaarde;
end

% We hebben dit nu met een for-loop gedaan. Doe dit nu zelf zonder for loop

%% Maak een plot van de metingen in percentage MVC
figure
plot(tijdKracht,krachtInMVC);
xlabel('Tijd [s]');
ylabel('Percentage MVX [%]');
title('De krachtmetingen in % MVC');

%% We willen nu weten welke meting gemiddeld dhet hoogste percentage MVC had
%
% Eerst middelen we de krachtmetingen over de tijd
gemiddeldPercentageMVC = mean(krachtInMVC,1);
% Vervolgens maken we een bar-plot
bar(gemiddeldPercentageMVC);
xlabel('Meting nummer');
ylabel('Percentage MVC');
title('Het gemiddelde % MVC voor elke meting');

%% Nu willen we een nieuw figuur maken met 2 subplots
% We willen ook dat de meting met het hoogste gemiddelde % MVC dik gedrukt 
% wordt in de eerste subplot en rood gekleurd wordt in de bar plot
%
% We bepalen welke meting het grootste gemiddelde percentage MVC had
[maxMeting, indexMaxMeting] = max(gemiddeldPercentageMVC);
% We gebruiken de index indexMaxMeting om te bepalen welke meting het
% grootst is

figure
subplot(2,1,1)
plot(tijdKracht,krachtInMVC);
hold on
plot(tijdKracht,krachtInMVC(:,indexMaxMeting),'k','lineWidth',2);
xlabel('Tijd [s]');
ylabel('Percentage MVX [%]');
title('De krachtmetingen in % MVC');
subplot(2,1,2)
bar(gemiddeldPercentageMVC);
hold on
bar(indexMaxMeting,maxMeting,'r')
xlabel('Meting nummer');
ylabel('Percentage MVC');
title('Het gemiddelde % MVC voor elke meting');
text(indexMaxMeting,maxMeting,['De meting met het hoogstegemiddelde % MVC is meting ' num2str(indexMaxMeting)]);



